$('.banner_sl').owlCarousel({
   navigation : true, // Show next and prev buttons
	autoplay:true,
	 items:1,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
	
	
	
$('.gallery').owlCarousel({
   navigation : true, // Show next and prev buttons
	autoplay:true,
	 items:4,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
	
	